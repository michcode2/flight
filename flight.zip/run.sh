rm log.log; touch log.log; cargo run
